# ELK-LOGS
open-source log management platform consisting of Elasticsearch, Logstash, and Kibana.
